package collections2;

public enum FloorType {
	HARDWOOD, LAMINATE, LINOLEUM, CERAMIC, STONE, CARPET, VYNIL, CONCRETE
}
