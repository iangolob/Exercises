package collections.z4;

import collections.z3.LadderEnhanced;

public class LadderEnhancedByLossesOrder extends LadderEnhanced {

}
