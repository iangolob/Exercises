package excersise11.z3;

public enum Gender {
	MALE, FEMALE
}
